@echo off
echo ========================================
echo     AlexRes - Build EXE
echo     par Alex
echo ========================================
echo.

:: Verifier Python
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERREUR] Python n'est pas installe ou pas dans le PATH.
    echo Telecharge Python sur https://python.org
    pause
    exit /b 1
)

:: Installer PyInstaller
echo [1/3] Installation de PyInstaller...
pip install pyinstaller --quiet

:: Build
echo [2/3] Compilation en cours...
pyinstaller --onefile --noconsole --name "AlexRes" --add-data "ui.html;." alexres.pyw

:: Resultat
echo.
if exist "dist\AlexRes.exe" (
    echo [3/3] SUCCES ! Ton exe est dans le dossier : dist\AlexRes.exe
) else (
    echo [3/3] ERREUR lors de la compilation.
)
echo.
pause
