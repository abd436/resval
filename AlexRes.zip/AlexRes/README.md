# AlexRes

**True Stretch Resolution Tool for VALORANT**  
Créé par **Alex**

---

## C'est quoi AlexRes ?

AlexRes te permet de changer ta résolution Windows en un clic pour jouer en True Stretch sur VALORANT, et de retrouver ta résolution d'origine automatiquement quand tu fermes le jeu.

---

## Fonctionnalités

- Changement de résolution en un clic
- Résolutions populaires prêtes à l'emploi
- Presets personnalisables
- Restauration automatique à la fermeture de VALORANT
- Interface sombre bleu/violet dans le navigateur
- Journal des actions
- Paramètres (auto-restore, raccourci clavier)

---

## Prérequis

- Windows 10 / 11
- Python 3.10+
- Driver GPU (NVIDIA / AMD / Intel) avec ta résolution custom déjà enregistrée

---

## Installation

1. Télécharge ou clone le dossier `AlexRes`
2. Lance `alexres.pyw` avec Python

```
python alexres.pyw
```

L'interface s'ouvre automatiquement dans ton navigateur.

---

## Utilisation

1. **Enregistre ta résolution custom** dans ton panneau GPU (NVIDIA Control Panel, AMD Software, etc.)
2. Lance AlexRes
3. Clique sur une résolution populaire ou tape la tienne
4. Lance VALORANT et profite du True Stretch
5. Quand tu fermes VALORANT, AlexRes restaure automatiquement ta résolution

---

## Auteur

**Alex** — AlexRes v1.0.0
