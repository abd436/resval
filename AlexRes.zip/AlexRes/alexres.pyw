"""
AlexRes - True Stretch Resolution Tool for VALORANT
Created by Alex
"""

import os
import sys
import json
import time
import ctypes
import winreg
import threading
import subprocess
import webbrowser
import http.server
import socketserver
from pathlib import Path

# ─── Constants ────────────────────────────────────────────────────────────────

APP_NAME    = "AlexRes"
APP_VERSION = "1.0.0"
APP_AUTHOR  = "Alex"
APP_PORT    = 7842
DATA_DIR    = Path(os.getenv("LOCALAPPDATA")) / "AlexRes"
PRESETS_FILE = DATA_DIR / "presets.json"
SETTINGS_FILE = DATA_DIR / "settings.json"

POPULAR_RES = [
    "1440x1080", "1280x1024", "1600x1080",
    "1280x1080", "1280x960",  "1154x1080", "1080x1080"
]

# ─── Windows API ──────────────────────────────────────────────────────────────

class DEVMODE(ctypes.Structure):
    _fields_ = [
        ("dmDeviceName",       ctypes.c_wchar * 32),
        ("dmSpecVersion",      ctypes.c_ushort),
        ("dmDriverVersion",    ctypes.c_ushort),
        ("dmSize",             ctypes.c_ushort),
        ("dmDriverExtra",      ctypes.c_ushort),
        ("dmFields",           ctypes.c_ulong),
        ("dmPositionX",        ctypes.c_long),
        ("dmPositionY",        ctypes.c_long),
        ("dmDisplayOrientation", ctypes.c_ulong),
        ("dmDisplayFixedOutput", ctypes.c_ulong),
        ("dmColor",            ctypes.c_short),
        ("dmDuplex",           ctypes.c_short),
        ("dmYResolution",      ctypes.c_short),
        ("dmTTOption",         ctypes.c_short),
        ("dmCollate",          ctypes.c_short),
        ("dmFormName",         ctypes.c_wchar * 32),
        ("dmLogPixels",        ctypes.c_ushort),
        ("dmBitsPerPel",       ctypes.c_ulong),
        ("dmPelsWidth",        ctypes.c_ulong),
        ("dmPelsHeight",       ctypes.c_ulong),
        ("dmDisplayFlags",     ctypes.c_ulong),
        ("dmDisplayFrequency", ctypes.c_ulong),
        ("dmICMMethod",        ctypes.c_ulong),
        ("dmICMIntent",        ctypes.c_ulong),
        ("dmMediaType",        ctypes.c_ulong),
        ("dmDitherType",       ctypes.c_ulong),
        ("dmReserved1",        ctypes.c_ulong),
        ("dmReserved2",        ctypes.c_ulong),
        ("dmPanningWidth",     ctypes.c_ulong),
        ("dmPanningHeight",    ctypes.c_ulong),
    ]

def get_current_resolution():
    """Return current display resolution as (width, height)."""
    user32 = ctypes.windll.user32
    return user32.GetSystemMetrics(0), user32.GetSystemMetrics(1)

def set_resolution(width: int, height: int) -> bool:
    """Change the primary display resolution. Returns True on success."""
    dm = DEVMODE()
    dm.dmSize = ctypes.sizeof(DEVMODE)
    dm.dmPelsWidth  = width
    dm.dmPelsHeight = height
    dm.dmFields = 0x00080000 | 0x00100000  # DM_PELSWIDTH | DM_PELSHEIGHT
    result = ctypes.windll.user32.ChangeDisplaySettingsW(ctypes.byref(dm), 0)
    return result == 0  # DISP_CHANGE_SUCCESSFUL

def is_valorant_running() -> bool:
    """Check if VALORANT process is active."""
    try:
        output = subprocess.check_output(
            ["tasklist", "/FI", "IMAGENAME eq VALORANT-Win64-Shipping.exe"],
            stderr=subprocess.DEVNULL
        ).decode()
        return "VALORANT" in output
    except Exception:
        return False

# ─── Data helpers ─────────────────────────────────────────────────────────────

def ensure_data_dir():
    DATA_DIR.mkdir(parents=True, exist_ok=True)

def load_presets() -> list:
    ensure_data_dir()
    if PRESETS_FILE.exists():
        try:
            return json.loads(PRESETS_FILE.read_text())
        except Exception:
            return []
    return []

def save_presets(presets: list):
    ensure_data_dir()
    PRESETS_FILE.write_text(json.dumps(presets))

def load_settings() -> dict:
    ensure_data_dir()
    defaults = {"auto_restore": True, "hotkey": True}
    if SETTINGS_FILE.exists():
        try:
            data = json.loads(SETTINGS_FILE.read_text())
            defaults.update(data)
            return defaults
        except Exception:
            return defaults
    return defaults

def save_settings(settings: dict):
    ensure_data_dir()
    SETTINGS_FILE.write_text(json.dumps(settings))

# ─── App state ────────────────────────────────────────────────────────────────

class AppState:
    def __init__(self):
        w, h = get_current_resolution()
        self.original_res   = f"{w}x{h}"
        self.current_res    = f"{w}x{h}"
        self.last_stretch   = None
        self.presets        = load_presets()
        self.settings       = load_settings()
        self.log            = ["> AlexRes prêt."]
        self.valorant_was_running = False

    def add_log(self, msg: str):
        ts = time.strftime("%H:%M:%S")
        self.log.append(f"[{ts}] {msg}")
        if len(self.log) > 100:
            self.log = self.log[-100:]

    def apply_resolution(self, res_str: str) -> dict:
        try:
            parts = res_str.lower().replace(" ", "").split("x")
            w, h = int(parts[0]), int(parts[1])
        except Exception:
            return {"ok": False, "msg": "Format invalide. Utilise ex: 1440x1080"}

        cur_w, cur_h = get_current_resolution()
        if cur_w == w and cur_h == h:
            return {"ok": True, "msg": f"Déjà en {res_str}."}

        ok = set_resolution(w, h)
        if ok:
            self.last_stretch = res_str
            self.current_res  = res_str
            self.add_log(f"Résolution appliquée : {res_str}")
            return {"ok": True, "msg": f"✓ {res_str} appliqué."}
        else:
            self.add_log(f"Échec : {res_str} non reconnue par le driver GPU.")
            return {"ok": False, "msg": f"Windows a refusé {res_str}. Enregistre d'abord cette résolution dans ton panneau GPU."}

    def restore_original(self) -> dict:
        return self.apply_resolution(self.original_res)

    def to_dict(self) -> dict:
        w, h = get_current_resolution()
        self.current_res = f"{w}x{h}"
        return {
            "version":      APP_VERSION,
            "author":       APP_AUTHOR,
            "original_res": self.original_res,
            "current_res":  self.current_res,
            "last_stretch": self.last_stretch,
            "presets":      self.presets,
            "settings":     self.settings,
            "log":          self.log[-30:],
            "popular":      POPULAR_RES,
            "valorant":     is_valorant_running(),
        }

state = AppState()

# ─── Auto-restore watcher ─────────────────────────────────────────────────────

def valorant_watcher():
    while True:
        running = is_valorant_running()
        if state.valorant_was_running and not running:
            if state.settings.get("auto_restore") and state.current_res != state.original_res:
                state.add_log("VALORANT fermé — restauration de la résolution originale.")
                state.restore_original()
        state.valorant_was_running = running
        time.sleep(3)

threading.Thread(target=valorant_watcher, daemon=True).start()

# ─── HTTP handler ─────────────────────────────────────────────────────────────

UI_PATH = Path(__file__).parent / "ui.html"

class Handler(http.server.SimpleHTTPRequestHandler):

    def log_message(self, *args):
        pass  # silence server logs

    def do_GET(self):
        if self.path == "/" or self.path == "/index.html":
            content = UI_PATH.read_bytes()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(content)))
            self.end_headers()
            self.wfile.write(content)

        elif self.path == "/api/state":
            data = json.dumps(state.to_dict()).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(data)

        else:
            self.send_response(404)
            self.end_headers()

    def do_POST(self):
        length  = int(self.headers.get("Content-Length", 0))
        payload = json.loads(self.rfile.read(length)) if length else {}
        result  = {}

        if self.path == "/api/apply":
            result = state.apply_resolution(payload.get("res", ""))

        elif self.path == "/api/restore":
            result = state.restore_original()

        elif self.path == "/api/presets/add":
            res = payload.get("res", "").strip()
            if res and res not in state.presets:
                state.presets.append(res)
                save_presets(state.presets)
                result = {"ok": True}
            else:
                result = {"ok": False, "msg": "Preset déjà existant ou vide."}

        elif self.path == "/api/presets/delete":
            res = payload.get("res", "")
            if res in state.presets:
                state.presets.remove(res)
                save_presets(state.presets)
            result = {"ok": True}

        elif self.path == "/api/settings":
            state.settings.update(payload)
            save_settings(state.settings)
            result = {"ok": True}

        data = json.dumps(result).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(data)

# ─── Launch ───────────────────────────────────────────────────────────────────

def start_server():
    with socketserver.TCPServer(("127.0.0.1", APP_PORT), Handler) as httpd:
        httpd.serve_forever()

threading.Thread(target=start_server, daemon=True).start()
time.sleep(0.4)
webbrowser.open(f"http://127.0.0.1:{APP_PORT}")

# Keep process alive
try:
    while True:
        time.sleep(1)
except KeyboardInterrupt:
    sys.exit(0)
